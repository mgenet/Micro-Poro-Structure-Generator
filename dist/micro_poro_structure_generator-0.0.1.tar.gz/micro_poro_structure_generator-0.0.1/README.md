# Geometry Generator

Library used in [Manoochehrtayebi, Bel-Brunon & Genet, Finite strain micro-poro-mechanics: formulation and compared analysis with macro-poro-mechanics. To be submitted.]

Demos available in [demos.ipynb](demos.ipynb)